export interface Author {
  id: string;
  name: string;
  initials?: string;
  avatar?: string;
  affiliation: string;
  email?: string;
}

export interface Category {
  id: string;
  label: string;
  icon?: string;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content?: string;
  category: Category;
  author: Author;
  date: string;
  citations: number;
  readingTime: number; // in minutes
  featured?: boolean;
  tags?: string[];
  journal?: string;
  doi?: string;
  abstract?: string;
}

export interface ArticleCardProps {
  title: string;
  excerpt: string;
  category: string;
  author: {
    name: string;
    avatar?: string;
  };
  date: string;
  readingTime: number;
  featured?: boolean;
  variant?: 'default' | 'compact';
}

export interface FeaturedArticleCardProps {
  title: string;
  excerpt: string;
  category: {
    label: string;
    icon?: React.ReactNode;
  };
  date: string;
  citations: number;
  author: {
    name: string;
    avatar: string; // or initials
    affiliation: string;
  };
  readingTime: number; // in minutes
  onRead?: () => void;
  onLike?: () => void;
  isLiked?: boolean;
}

export interface ListParams {
  category?: string;
  author?: string;
  search?: string;
  page?: number;
  limit?: number;
  sort?: 'date' | 'citations' | 'title';
  order?: 'asc' | 'desc';
}