import { create } from 'zustand';
import { Article } from '@/types/article';

interface ArticleStore {
  articles: Article[];
  featured: Article | null;
  favorites: Set<string>;
  loading: boolean;
  error: string | null;
  
  // Actions
  fetchArticles: () => Promise<void>;
  fetchFeatured: () => Promise<void>;
  toggleFavorite: (id: string) => void;
  setFeatured: (article: Article) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

export const useArticleStore = create<ArticleStore>((set, get) => ({
  articles: [],
  featured: null,
  favorites: new Set(),
  loading: false,
  error: null,
  
  fetchArticles: async () => {
    set({ loading: true, error: null });
    
    try {
      // Mock data - in real app, this would be an API call
      const mockArticles: Article[] = [
        {
          id: '1',
          title: 'Análise Comportamental Aplicada na Educação Especial',
          excerpt: 'Um estudo exploratório sobre a aplicação de princípios da análise do comportamento em salas de aula inclusivas.',
          category: { id: 'edu', label: 'Educação' },
          author: {
            id: 'author1',
            name: 'Dra. Maria Oliveira',
            initials: 'MO',
            affiliation: 'Universidade de São Paulo'
          },
          date: '2025-12-12',
          citations: 45,
          readingTime: 8,
          featured: false
        },
        {
          id: '2',
          title: 'Intervenções Comportamentais para Transtornos de Ansiedade',
          excerpt: 'Investigação sobre a eficácia de protocolos de exposição gradual e reforçamento positivo.',
          category: { id: 'clin', label: 'Clínica' },
          author: {
            id: 'author2',
            name: 'Dr. Carlos Santos',
            initials: 'CS',
            affiliation: 'Universidade Federal do Rio de Janeiro'
          },
          date: '2025-12-10',
          citations: 32,
          readingTime: 12,
          featured: false
        }
      ];
      
      set({ articles: mockArticles, loading: false });
    } catch (error) {
      set({ error: 'Falha ao carregar artigos', loading: false });
    }
  },
  
  fetchFeatured: async () => {
    set({ loading: true, error: null });
    
    try {
      // Mock data - in real app, this would be an API call
      const mockFeatured: Article = {
        id: 'featured1',
        title: 'Avanços na Terapia Comportamental para Transtornos do Espectro Autista',
        excerpt: 'Esta revisão sistemática examina os desenvolvimentos recentes na terapia comportamental aplicada ao tratamento de transtornos do espectro autista.',
        category: { id: 'therapy', label: 'Terapia Comportamental' },
        author: {
          id: 'author3',
          name: 'Dra. Ana Silva',
          initials: 'AS',
          affiliation: 'Universidade de São Paulo - Departamento de Psicologia'
        },
        date: '2025-12-15',
        citations: 47,
        readingTime: 14,
        featured: true
      };
      
      set({ featured: mockFeatured, loading: false });
    } catch (error) {
      set({ error: 'Falha ao carregar artigo em destaque', loading: false });
    }
  },
  
  toggleFavorite: (id: string) => {
    set((state) => {
      const newFavorites = new Set(state.favorites);
      if (newFavorites.has(id)) {
        newFavorites.delete(id);
      } else {
        newFavorites.add(id);
      }
      return { favorites: newFavorites };
    });
  },
  
  setFeatured: (article: Article) => set({ featured: article }),
  setLoading: (loading: boolean) => set({ loading }),
  setError: (error: string | null) => set({ error })
}));