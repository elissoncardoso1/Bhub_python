import { RepositoryPage } from '@/pages/RepositoryPage';

export default function Repository() {
  return <RepositoryPage />;
}