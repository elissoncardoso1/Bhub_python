import { ArticleDetailPage } from '@/pages/ArticleDetailPage';

export default function ArticleDetail() {
  return <ArticleDetailPage />;
}