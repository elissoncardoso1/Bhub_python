'use client';

import React from 'react';
import { Header } from '@/components/Layout/Header';
import { Footer } from '@/components/Layout/Footer';
import { MainLayout } from '@/components/Layout/MainLayout';

export default function About() {
  return (
    <MainLayout>
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-sm">
          <h1 className="font-display font-bold text-3xl text-bhub-navy-dark dark:text-white mb-6">
            Sobre o BHub
          </h1>
          
          <div className="space-y-6 font-body font-light text-gray-700 dark:text-gray-300 leading-relaxed">
            <p>
              O BHub é um repositório científico dedicado à análise do comportamento, 
              conectando pesquisadores e promovendo o conhecimento científico nesta área fundamental da psicologia.
            </p>
            
            <p>
              Nossa missão é facilitar o acesso a pesquisas de qualidade, 
              promover colaboração entre acadêmicos e acelerar o avanço do conhecimento 
              em análise comportamental e suas aplicações práticas.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
              <div>
                <h2 className="font-display font-bold text-xl text-bhub-navy-dark dark:text-white mb-4">
                  Nossos Valores
                </h2>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="text-bhub-teal-primary">•</span>
                    <span>Excelência científica e rigor metodológico</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-bhub-teal-primary">•</span>
                    <span>Acesso aberto e democratização do conhecimento</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-bhub-teal-primary">•</span>
                    <span>Colaboração e intercâmbio acadêmico</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-bhub-teal-primary">•</span>
                    <span>Impacto social e aplicações práticas</span>
                  </li>
                </ul>
              </div>
              
              <div>
                <h2 className="font-display font-bold text-xl text-bhub-navy-dark dark:text-white mb-4">
                  Nossa Visão
                </h2>
                <p>
                  Ser o principal repositório mundial de pesquisa em análise do comportamento,
                  reconhecido pela qualidade, relevância e impacto das publicações que disponibilizamos.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </MainLayout>
  );
}