'use client';

import React, { useState } from 'react';
import { Header } from '@/components/Layout/Header';
import { Footer } from '@/components/Layout/Footer';
import { MainLayout } from '@/components/Layout/MainLayout';
import { ArticleCardList } from '@/components/ArticleCard/ArticleCardList';
import { Badge } from '@/components/Badge/Badge';
import { Button } from '@/components/Button/Button';
import { Icon } from '@/components/Icon/Icon';

export default function Search() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [isSearched, setIsSearched] = useState(false);

  const categories = [
    'Todas',
    'Comportamento',
    'Cognição',
    'Terapia',
    'Educação',
    'Pesquisa',
    'Clínica'
  ];

  const mockResults = [
    {
      title: 'Análise Funcional do Comportamento em Contextos Educacionais',
      excerpt: 'Um estudo exploratório sobre a aplicação de princípios da análise do comportamento em salas de aula inclusivas.',
      category: 'Educação',
      author: {
        name: 'Carlos Santos',
        avatar: 'CS'
      },
      date: '12 Dez 2025',
      readingTime: 8,
      featured: false
    },
    {
      title: 'Intervenções Comportamentais para Transtornos de Ansiedade',
      excerpt: 'Investigação sobre a eficácia de protocolos de exposição gradual e reforçamento positivo.',
      category: 'Clínica',
      author: {
        name: 'Maria Oliveira',
        avatar: 'MO'
      },
      date: '10 Dez 2025',
      readingTime: 12,
      featured: false
    },
    {
      title: 'Neuroplasticidade e Aprendizagem: Perspectivas Comportamentais',
      excerpt: 'Análise das correlações entre mudanças comportamentais observáveis e adaptações neurais.',
      category: 'Pesquisa',
      author: {
        name: 'João Costa',
        avatar: 'JC'
      },
      date: '8 Dez 2025',
      readingTime: 16,
      featured: false
    }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearched(true);
    console.log('Searching for:', searchTerm, 'Category:', selectedCategory);
  };

  const clearSearch = () => {
    setSearchTerm('');
    setSelectedCategory('');
    setIsSearched(false);
  };

  return (
    <MainLayout>
      <Header />
      
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Search Header */}
          <div className="text-center mb-12">
            <h1 className="font-display font-bold text-4xl text-bhub-navy-dark dark:text-white mb-4">
              Buscar Artigos
            </h1>
            <p className="font-body font-light text-lg text-gray-600 dark:text-gray-400">
              Encontre artigos, autores e tópicos de seu interesse
            </p>
          </div>

          {/* Search Form */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700 mb-8">
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Icon 
                      name="search" 
                      className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                    />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Buscar artigos, autores ou palavras-chave..."
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-bhub-teal-primary focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                    />
                  </div>
                </div>
                
                <div className="md:w-64">
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-bhub-teal-primary focus:border-transparent bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                  >
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                <Button
                  type="submit"
                  variant="default"
                  className="bg-bhub-teal-primary hover:bg-bhub-teal-primary/90"
                >
                  <Icon name="search" size="sm" />
                  Buscar
                </Button>
              </div>

              {/* Quick Filters */}
              <div className="flex flex-wrap gap-2">
                <span className="font-body font-medium text-sm text-gray-700 dark:text-gray-300">
                  Buscas populares:
                </span>
                {['Terapia Cognitivo-Comportamental', 'Análise Aplicada', 'Autismo', 'Educação Especial'].map((term) => (
                  <Button
                    key={term}
                    variant="outline"
                    size="sm"
                    onClick={() => setSearchTerm(term)}
                    className="text-xs"
                  >
                    {term}
                  </Button>
                ))}
              </div>
            </form>
          </div>

          {/* Search Results */}
          {isSearched && (
            <div>
              {/* Results Header */}
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="font-display font-bold text-2xl text-bhub-navy-dark dark:text-white mb-2">
                    Resultados da Busca
                  </h2>
                  <p className="font-body font-light text-gray-600 dark:text-gray-400">
                    {mockResults.length} resultados encontrados para "{searchTerm}"
                  </p>
                </div>
                
                <Button
                  variant="outline"
                  onClick={clearSearch}
                  className="flex items-center gap-2"
                >
                  <Icon name="close" size="sm" />
                  Limpar Busca
                </Button>
              </div>

              {/* Results List */}
              {mockResults.length > 0 ? (
                <ArticleCardList 
                  articles={mockResults}
                  columns={2}
                />
              ) : (
                <div className="text-center py-12">
                  <Icon name="search" className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="font-display font-bold text-xl text-gray-900 dark:text-white mb-2">
                    Nenhum resultado encontrado
                  </h3>
                  <p className="font-body font-light text-gray-600 dark:text-gray-400 mb-6">
                    Tente usar termos diferentes ou verifique a ortografia
                  </p>
                  <Button
                    variant="outline"
                    onClick={clearSearch}
                  >
                    Nova Busca
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Search Tips */}
          {!isSearched && (
            <div className="bg-bhub-navy-light dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
              <h3 className="font-display font-bold text-xl text-bhub-navy-dark dark:text-white mb-4">
                Dicas de Busca
              </h3>
              <div className="space-y-3 font-body font-light text-gray-700 dark:text-gray-300">
                <p className="flex items-start gap-2">
                  <span className="text-bhub-teal-primary">•</span>
                  <span>Use termos específicos como "análise funcional" em vez de "comportamento"</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="text-bhub-teal-primary">•</span>
                  <span>Busque por nomes de autores ou palavras-chave específicas</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="text-bhub-teal-primary">•</span>
                  <span>Use aspas para buscar frases exatas: "terapia comportamental"</span>
                </p>
                <p className="flex items-start gap-2">
                  <span className="text-bhub-teal-primary">•</span>
                  <span>Combine termos com operadores: autismo AND terapia</span>
                </p>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </MainLayout>
  );
}