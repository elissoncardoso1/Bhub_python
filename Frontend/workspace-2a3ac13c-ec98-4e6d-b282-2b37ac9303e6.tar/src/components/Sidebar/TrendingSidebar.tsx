'use client';

import React from 'react';
import { Badge } from '@/components/Badge/Badge';
import { Avatar } from '@/components/Avatar/Avatar';
import { Icon } from '@/components/Icon/Icon';
import { cn } from '@/lib/utils';

interface TrendingSidebarProps {
  className?: string;
}

export function TrendingSidebar({ className }: TrendingSidebarProps) {
  const trendingArticles = [
    {
      id: '1',
      title: 'Análise Comportamental Aplicada na Educação Especial',
      author: 'Dra. Maria Oliveira',
      citations: 145,
      category: 'Educação',
      trend: 'up'
    },
    {
      id: '2',
      title: 'Terapia Comportamental Cognitiva para Transtornos de Ansiedade',
      author: 'Dr. Carlos Santos',
      citations: 98,
      category: 'Terapia',
      trend: 'up'
    },
    {
      id: '3',
      title: 'Neurociência do Comportamento Humano',
      author: 'Dr. João Costa',
      citations: 76,
      category: 'Pesquisa',
      trend: 'stable'
    },
    {
      id: '4',
      title: 'Intervenção Comportamental em Autismo',
      author: 'Dra. Ana Silva',
      citations: 65,
      category: 'Clínica',
      trend: 'up'
    },
    {
      id: '5',
      title: 'Princípios da Análise Experimental do Comportamento',
      author: 'Dr. Pedro Lima',
      citations: 52,
      category: 'Comportamento',
      trend: 'down'
    }
  ];

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return <Icon name="trending" className="text-green-500" />;
      case 'down':
        return <Icon name="trending" className="text-red-500 rotate-180" />;
      default:
        return <Icon name="trending" className="text-gray-400 rotate-90" />;
    }
  };

  return (
    <aside className={cn('bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700', className)}>
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <Icon name="trending" className="text-bhub-teal-primary" />
        <h3 className="font-display font-bold text-lg text-bhub-navy-dark dark:text-white">
          Em Alta
        </h3>
      </div>

      {/* Trending Articles */}
      <div className="space-y-4">
        {trendingArticles.map((article, index) => (
          <article 
            key={article.id}
            className="pb-4 border-b border-gray-100 dark:border-gray-700 last:border-b-0 last:pb-0"
          >
            <div className="flex items-start gap-3">
              {/* Rank */}
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-bhub-navy-light dark:bg-bhub-navy-dark flex items-center justify-center">
                <span className="font-display font-bold text-xs text-bhub-navy-dark dark:text-white">
                  {index + 1}
                </span>
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                <h4 className="font-body font-medium text-sm text-gray-900 dark:text-white mb-1 line-clamp-2 hover:text-bhub-teal-primary cursor-pointer transition-colors">
                  {article.title}
                </h4>
                
                <div className="flex items-center gap-2 mb-2">
                  <Badge 
                    label={article.category}
                    variant="light"
                    className="text-xs"
                  />
                  <div className="flex items-center gap-1">
                    {getTrendIcon(article.trend as any)}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <p className="font-body font-light text-xs text-gray-600 dark:text-gray-400">
                    {article.author}
                  </p>
                  <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
                    <Icon name="star" size="sm" />
                    {article.citations}
                  </div>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* View More Link */}
      <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700">
        <a
          href="/trending"
          className="flex items-center justify-center gap-2 text-sm font-body font-medium text-bhub-teal-primary hover:text-bhub-teal-primary/80 transition-colors"
        >
          Ver todos os artigos em alta
          <Icon name="chevronRight" size="sm" />
        </a>
      </div>
    </aside>
  );
}