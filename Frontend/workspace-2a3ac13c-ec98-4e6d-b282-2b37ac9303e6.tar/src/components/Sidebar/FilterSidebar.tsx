'use client';

import React, { useState } from 'react';
import { Badge } from '@/components/Badge/Badge';
import { Button } from '@/components/Button/Button';
import { Icon } from '@/components/Icon/Icon';
import { cn } from '@/lib/utils';

interface FilterSidebarProps {
  className?: string;
}

export function FilterSidebar({ className }: FilterSidebarProps) {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedAuthors, setSelectedAuthors] = useState<string[]>([]);
  const [dateRange, setDateRange] = useState<string>('all');

  const categories = [
    { id: 'behavior', label: 'Comportamento', count: 45 },
    { id: 'cognition', label: 'Cognição', count: 32 },
    { id: 'therapy', label: 'Terapia', count: 28 },
    { id: 'education', label: 'Educação', count: 19 },
    { id: 'research', label: 'Pesquisa', count: 36 },
    { id: 'clinical', label: 'Clínica', count: 24 }
  ];

  const authors = [
    { id: 'author1', name: 'Dr. Ana Silva', count: 12 },
    { id: 'author2', name: 'Dr. Carlos Santos', count: 8 },
    { id: 'author3', name: 'Dra. Maria Oliveira', count: 6 },
    { id: 'author4', name: 'Dr. João Costa', count: 5 }
  ];

  const dateRanges = [
    { value: 'all', label: 'Todos os períodos' },
    { value: 'week', label: 'Última semana' },
    { value: 'month', label: 'Último mês' },
    { value: 'quarter', label: 'Último trimestre' },
    { value: 'year', label: 'Último ano' }
  ];

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const toggleAuthor = (authorId: string) => {
    setSelectedAuthors(prev => 
      prev.includes(authorId) 
        ? prev.filter(id => id !== authorId)
        : [...prev, authorId]
    );
  };

  const clearFilters = () => {
    setSelectedCategories([]);
    setSelectedAuthors([]);
    setDateRange('all');
  };

  const hasActiveFilters = selectedCategories.length > 0 || 
                          selectedAuthors.length > 0 || 
                          dateRange !== 'all';

  return (
    <aside className={cn('bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700', className)}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-display font-bold text-lg text-bhub-navy-dark dark:text-white">
          Filtros
        </h3>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="text-bhub-teal-primary hover:text-bhub-teal-primary/80"
          >
            Limpar
          </Button>
        )}
      </div>

      {/* Categories */}
      <div className="mb-8">
        <h4 className="font-body font-semibold text-sm text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Icon name="filter" size="sm" />
          Categorias
        </h4>
        <div className="space-y-2">
          {categories.map((category) => (
            <label
              key={category.id}
              className="flex items-center justify-between p-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedCategories.includes(category.id)}
                  onChange={() => toggleCategory(category.id)}
                  className="rounded border-gray-300 text-bhub-teal-primary focus:ring-bhub-teal-primary"
                />
                <span className="font-body font-light text-sm text-gray-700 dark:text-gray-300">
                  {category.label}
                </span>
              </div>
              <span className="font-body font-light text-xs text-gray-500 dark:text-gray-400">
                {category.count}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Authors */}
      <div className="mb-8">
        <h4 className="font-body font-semibold text-sm text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Icon name="user" size="sm" />
          Autores
        </h4>
        <div className="space-y-2">
          {authors.map((author) => (
            <label
              key={author.id}
              className="flex items-center justify-between p-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors"
            >
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedAuthors.includes(author.id)}
                  onChange={() => toggleAuthor(author.id)}
                  className="rounded border-gray-300 text-bhub-teal-primary focus:ring-bhub-teal-primary"
                />
                <span className="font-body font-light text-sm text-gray-700 dark:text-gray-300">
                  {author.name}
                </span>
              </div>
              <span className="font-body font-light text-xs text-gray-500 dark:text-gray-400">
                {author.count}
              </span>
            </label>
          ))}
        </div>
      </div>

      {/* Date Range */}
      <div className="mb-6">
        <h4 className="font-body font-semibold text-sm text-gray-900 dark:text-white mb-4 flex items-center gap-2">
          <Icon name="calendar" size="sm" />
          Período
        </h4>
        <select
          value={dateRange}
          onChange={(e) => setDateRange(e.target.value)}
          className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white font-body font-light text-sm focus:ring-2 focus:ring-bhub-teal-primary focus:border-transparent"
        >
          {dateRanges.map((range) => (
            <option key={range.value} value={range.value}>
              {range.label}
            </option>
          ))}
        </select>
      </div>

      {/* Apply Filters Button */}
      <Button
        variant="default"
        className="w-full bg-bhub-teal-primary hover:bg-bhub-teal-primary/90 text-white"
        disabled={!hasActiveFilters}
      >
        Aplicar Filtros
      </Button>
    </aside>
  );
}