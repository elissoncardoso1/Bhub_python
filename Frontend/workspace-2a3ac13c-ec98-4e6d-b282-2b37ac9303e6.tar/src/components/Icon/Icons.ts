export { Icon } from './Icon';
export * from './Icon';