'use client';

import React, { useState } from 'react';
import { ArticleCardProps } from '@/types/article';
import { Badge } from '@/components/Badge/Badge';
import { Avatar } from '@/components/Avatar/Avatar';
import { IconButton, Button } from '@/components/Button/Button';
import { Icon } from '@/components/Icon/Icon';
import { cn } from '@/lib/utils';

export function ArticleCard({
  title,
  excerpt,
  category,
  author,
  date,
  readingTime,
  featured = false,
  variant = 'default'
}: ArticleCardProps) {
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);

  const handleLike = () => {
    setIsLiked(!isLiked);
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title,
        text: excerpt,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  const isCompact = variant === 'compact';

  return (
    <article 
      className={cn(
        "bg-white dark:bg-gray-800 rounded-lg p-4 md:p-6 border border-gray-200 dark:border-gray-700 transition-all hover:shadow-md",
        featured && "ring-2 ring-bhub-teal-primary/20"
      )}
    >
      {/* Header with metadata */}
      <header className={cn("mb-3", isCompact && "mb-2")}>
        <div className="flex items-center justify-between mb-2">
          <Badge 
            label={category}
            variant="default"
            className="text-xs"
          />
          <div className="flex items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
            <span>{date}</span>
          </div>
        </div>
        
        <h2 className={cn(
          "font-display font-bold text-bhub-navy-dark dark:text-white mb-2 leading-tight",
          isCompact ? "text-lg" : "text-xl"
        )}>
          {title}
        </h2>
        
        {!isCompact && (
          <p className="font-body font-light text-sm text-gray-600 dark:text-gray-300 mb-3 leading-relaxed line-clamp-3">
            {excerpt}
          </p>
        )}
      </header>

      {/* Author and metadata */}
      <div className={cn(
        "flex items-center justify-between mb-4",
        isCompact && "mb-3"
      )}>
        <div className="flex items-center gap-3">
          <Avatar 
            name={author.name}
            initials={author.avatar}
            size={isCompact ? "sm" : "md"}
          />
          <div>
            <p className="font-body font-medium text-sm text-gray-900 dark:text-white">
              {author.name}
            </p>
            {!isCompact && (
              <p className="font-body font-light text-xs text-gray-500 dark:text-gray-400">
                Journal of Behavior Analysis
              </p>
            )}
          </div>
        </div>
        
        <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
          <Icon name="clock" size="sm" />
          {readingTime} min
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1">
          <IconButton
            icon={<Icon name="heart" />}
            variant="ghost"
            size="sm"
            className={cn(
              "text-gray-400 hover:text-bhub-red-accent",
              isLiked && "text-bhub-red-accent"
            )}
            onClick={handleLike}
            aria-label="Curtir artigo"
          />
          <IconButton
            icon={<Icon name="bookmark" />}
            variant="ghost"
            size="sm"
            className={cn(
              "text-gray-400 hover:text-bhub-yellow-primary",
              isBookmarked && "text-bhub-yellow-primary"
            )}
            onClick={handleBookmark}
            aria-label="Salvar artigo"
          />
          <IconButton
            icon={<Icon name="share" />}
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-bhub-teal-primary"
            onClick={handleShare}
            aria-label="Compartilhar artigo"
          />
        </div>
        
        <Button
          variant="ghost"
          size="sm"
          className="text-bhub-teal-primary hover:text-bhub-teal-primary/80 hover:bg-bhub-teal-light/20 font-medium"
        >
          Ler Artigo
          <Icon name="chevronRight" size="sm" />
        </Button>
      </div>
    </article>
  );
}