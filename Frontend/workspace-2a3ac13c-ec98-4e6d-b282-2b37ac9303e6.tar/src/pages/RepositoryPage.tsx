'use client';

import React from 'react';
import { Header } from '@/components/Layout/Header';
import { Footer } from '@/components/Layout/Footer';
import { MainLayout } from '@/components/Layout/MainLayout';
import { Button } from '@/components/Button/Button';
import { Icon } from '@/components/Icon/Icon';
import { Badge } from '@/components/Badge/Badge';

export function RepositoryPage() {
  const resources = [
    {
      id: '1',
      title: 'Guia de Autores',
      description: 'Diretrizes completas para submissão de artigos e formatação according to standards.',
      icon: 'bookOpen',
      category: 'Guias',
      downloadCount: 1234,
      format: 'PDF',
      size: '2.4 MB'
    },
    {
      id: '2',
      title: 'Templates de Artigos',
      description: 'Templates oficiais para Microsoft Word e LaTeX compatíveis com as normas da BHub.',
      icon: 'fileText',
      category: 'Templates',
      downloadCount: 892,
      format: 'ZIP',
      size: '1.8 MB'
    },
    {
      id: '3',
      title: 'Política Editorial',
      description: 'Políticas editoriais, diretrizes éticas e critérios de avaliação por pares.',
      icon: 'award',
      category: 'Políticas',
      downloadCount: 567,
      format: 'PDF',
      size: '1.2 MB'
    },
    {
      id: '4',
      title: 'Manual de Estilo',
      description: 'Guia completo de estilo acadêmico, citações e referências bibliográficas.',
      icon: 'bookOpen',
      category: 'Guias',
      downloadCount: 445,
      format: 'PDF',
      size: '3.1 MB'
    },
    {
      id: '5',
      title: 'Checklist de Submissão',
      description: 'Checklist interativo para garantir que seu artigo atenda todos os requisitos.',
      icon: 'check',
      category: 'Ferramentas',
      downloadCount: 789,
      format: 'XLSX',
      size: '0.5 MB'
    },
    {
      id: '6',
      title: 'Tutorial de Submissão Online',
      description: 'Vídeo tutorial passo a passo sobre como submeter artigos através da plataforma.',
      icon: 'play',
      category: 'Tutoriais',
      downloadCount: 234,
      format: 'MP4',
      size: '45.2 MB'
    }
  ];

  const categories = ['Todos', 'Guias', 'Templates', 'Políticas', 'Ferramentas', 'Tutoriais'];
  const [selectedCategory, setSelectedCategory] = React.useState('Todos');

  const filteredResources = selectedCategory === 'Todos' 
    ? resources 
    : resources.filter(resource => resource.category === selectedCategory);

  const handleDownload = (resourceId: string) => {
    console.log(`Downloading resource: ${resourceId}`);
    // In a real app, this would trigger a download
  };

  return (
    <MainLayout>
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="font-display font-bold text-3xl md:text-4xl text-bhub-navy-dark dark:text-white mb-4">
            Repositório de Recursos
          </h1>
          <p className="font-body font-light text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Acesse guias, templates, políticas e ferramentas para facilitar sua experiência 
            como autor e pesquisador na BHub.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className={selectedCategory === category 
                ? "bg-bhub-teal-primary hover:bg-bhub-teal-primary/90" 
                : "text-gray-600 dark:text-gray-400 hover:text-bhub-teal-primary"
              }
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Resources Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredResources.map((resource) => (
            <div
              key={resource.id}
              className="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow"
            >
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-bhub-navy-light dark:bg-bhub-navy-dark rounded-lg flex items-center justify-center">
                  <Icon name={resource.icon as any} className="text-bhub-navy-dark dark:text-white" />
                </div>
                <Badge 
                  label={resource.category}
                  variant="light"
                  className="text-xs"
                />
              </div>

              {/* Content */}
              <h3 className="font-display font-semibold text-lg text-bhub-navy-dark dark:text-white mb-2">
                {resource.title}
              </h3>
              <p className="font-body font-light text-sm text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                {resource.description}
              </p>

              {/* Metadata */}
              <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 mb-4">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <Icon name="download" size="sm" />
                    {resource.downloadCount}
                  </span>
                  <span>{resource.format}</span>
                  <span>{resource.size}</span>
                </div>
              </div>

              {/* Download Button */}
              <Button
                variant="default"
                className="w-full bg-bhub-teal-primary hover:bg-bhub-teal-primary/90 text-white"
                onClick={() => handleDownload(resource.id)}
              >
                <Icon name="download" size="sm" />
                Baixar Recurso
              </Button>
            </div>
          ))}
        </div>

        {/* Additional Resources Section */}
        <section className="bg-gradient-to-br from-bhub-navy-dark to-bhub-dark-gray rounded-lg p-8 text-white">
          <div className="text-center mb-8">
            <h2 className="font-display font-bold text-2xl mb-4">
              Recursos Adicionais
            </h2>
            <p className="font-body font-light text-gray-300">
              Explore mais ferramentas e materiais para potencializar sua pesquisa
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
              <div className="flex items-center gap-3 mb-4">
                <Icon name="users" className="text-bhub-teal-primary" />
                <h3 className="font-body font-semibold text-lg">Comunidade</h3>
              </div>
              <p className="font-body font-light text-sm text-gray-300 mb-4">
                Participe de fóruns de discussão, webinars e eventos exclusivos para autores.
              </p>
              <Button variant="ghost" className="text-bhub-teal-primary hover:text-bhub-teal-light">
                Explorar Comunidade
                <Icon name="chevronRight" size="sm" />
              </Button>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
              <div className="flex items-center gap-3 mb-4">
                <Icon name="barChart3" className="text-bhub-teal-primary" />
                <h3 className="font-body font-semibold text-lg">Estatísticas</h3>
              </div>
              <p className="font-body font-light text-sm text-gray-300 mb-4">
                Acesse métricas detalhadas sobre downloads, citações e impacto de seus artigos.
              </p>
              <Button variant="ghost" className="text-bhub-teal-primary hover:text-bhub-teal-light">
                Ver Estatísticas
                <Icon name="chevronRight" size="sm" />
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </MainLayout>
  );
}