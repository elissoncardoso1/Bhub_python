'use client';

import React from 'react';
import { Header } from '@/components/Layout/Header';
import { Footer } from '@/components/Layout/Footer';
import { MainLayout } from '@/components/Layout/MainLayout';
import { FeaturedArticleCard } from '@/components/ArticleCard/FeaturedArticleCard';
import { ArticleCardList } from '@/components/ArticleCard/ArticleCardList';
import { FilterSidebar } from '@/components/Sidebar/FilterSidebar';
import { TrendingSidebar } from '@/components/Sidebar/TrendingSidebar';
import { NewsletterCard } from '@/components/Sidebar/NewsletterCard';
import { cn } from '@/lib/utils';

export function HomePage() {
  // Mock data for featured article
  const featuredArticle = {
    title: "Avanços na Terapia Comportamental para Transtornos do Espectro Autista: Uma Revisão Sistemática",
    excerpt: "Esta revisão sistemática examina os desenvolvimentos recentes na terapia comportamental aplicada ao tratamento de transtornos do espectro autista, destacando abordagens inovadoras e resultados clínicos significativos obtidos nos últimos cinco anos de pesquisa.",
    category: {
      label: "Terapia Comportamental",
      icon: null
    },
    date: "15 Dez 2025",
    citations: 47,
    author: {
      name: "Ana Silva",
      avatar: "AS",
      affiliation: "Universidade de São Paulo - Departamento de Psicologia"
    },
    readingTime: 14,
    isLiked: false,
    onRead: () => console.log('Read featured article'),
    onLike: () => console.log('Like featured article')
  };

  // Mock data for article list
  const articles = [
    {
      title: "Análise Funcional do Comportamento em Contextos Educacionais",
      excerpt: "Um estudo exploratório sobre a aplicação de princípios da análise do comportamento em salas de aula inclusivas, demonstrando melhorias significativas no engajamento acadêmico.",
      category: "Educação",
      author: {
        name: "Carlos Santos",
        avatar: "CS"
      },
      date: "12 Dez 2025",
      readingTime: 8,
      featured: false
    },
    {
      title: "Intervenções Comportamentais para Transtornos de Ansiedade na Infância",
      excerpt: "Investigação sobre a eficácia de protocolos de exposição gradual e reforçamento positivo no tratamento de fobias específicas em crianças entre 6-12 anos.",
      category: "Clínica",
      author: {
        name: "Maria Oliveira",
        avatar: "MO"
      },
      date: "10 Dez 2025",
      readingTime: 12,
      featured: false
    },
    {
      title: "Neuroplasticidade e Aprendizagem: Perspectivas Comportamentais",
      excerpt: "Análise das correlações entre mudanças comportamentais observáveis e adaptações neurais documentadas através de neuroimagem funcional.",
      category: "Pesquisa",
      author: {
        name: "João Costa",
        avatar: "JC"
      },
      date: "8 Dez 2025",
      readingTime: 16,
      featured: false
    },
    {
      title: "Gestão de Comportamento Organizacional: Estudo de Caso em Tecnologia",
      excerpt: "Aplicação de princípios do behaviorismo radical na gestão de equipes de desenvolvimento de software, com foco em produtividade e bem-estar.",
      category: "Organizacional",
      author: {
        name: "Pedro Lima",
        avatar: "PL"
      },
      date: "5 Dez 2025",
      readingTime: 10,
      featured: false
    },
    {
      title: "Avaliação de Programas de Reforçamento em Educação Especial",
      excerpt: "Meta-análise sobre a eficácia de diferentes sistemas de reforçamento em alunos com necessidades educacionais especiais.",
      category: "Educação",
      author: {
        name: "Fernanda Dias",
        avatar: "FD"
      },
      date: "3 Dez 2025",
      readingTime: 9,
      featured: false
    },
    {
      title: "Comportamento Verbal e Habilidades de Comunicação em Autismo",
      excerpt: "Revisão crítica sobre abordagens contemporâneas no desenvolvimento de linguagem funcional em crianças com transtornos do espectro autista.",
      category: "Clínica",
      author: {
        name: "Roberto Mendes",
        avatar: "RM"
      },
      date: "1 Dez 2025",
      readingTime: 11,
      featured: false
    }
  ];

  return (
    <MainLayout>
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Desktop Layout */}
        <div className="hidden lg:grid grid-cols-[240px_1fr_280px] gap-6">
          {/* Sidebar Left */}
          <div className="space-y-6">
            <FilterSidebar />
          </div>
          
          {/* Main Content */}
          <div className="space-y-8">
            {/* Featured Article */}
            <FeaturedArticleCard {...featuredArticle} />
            
            {/* Recent Articles Section */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display font-bold text-2xl text-bhub-navy-dark dark:text-white">
                  Artigos Recentes
                </h2>
                <a
                  href="/articles"
                  className="text-bhub-teal-primary hover:text-bhub-teal-primary/80 font-body font-medium text-sm flex items-center gap-1"
                >
                  Ver todos
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </a>
              </div>
              
              <ArticleCardList 
                articles={articles} 
                columns={2}
              />
            </section>
          </div>
          
          {/* Sidebar Right */}
          <div className="space-y-6">
            <TrendingSidebar />
            <NewsletterCard />
          </div>
        </div>

        {/* Tablet Layout */}
        <div className="hidden md:grid lg:hidden grid-cols-[1fr_280px] gap-6">
          {/* Main Content */}
          <div className="space-y-8">
            {/* Featured Article */}
            <FeaturedArticleCard {...featuredArticle} />
            
            {/* Recent Articles Section */}
            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-display font-bold text-2xl text-bhub-navy-dark dark:text-white">
                  Artigos Recentes
                </h2>
                <a
                  href="/articles"
                  className="text-bhub-teal-primary hover:text-bhub-teal-primary/80 font-body font-medium text-sm flex items-center gap-1"
                >
                  Ver todos
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </a>
              </div>
              
              <ArticleCardList 
                articles={articles} 
                columns={1}
              />
            </section>
          </div>
          
          {/* Sidebar Right */}
          <div className="space-y-6">
            <TrendingSidebar />
            <NewsletterCard />
          </div>
        </div>

        {/* Mobile Layout */}
        <div className="md:hidden space-y-6">
          {/* Featured Article */}
          <FeaturedArticleCard {...featuredArticle} />
          
          {/* Trending Sidebar */}
          <TrendingSidebar />
          
          {/* Recent Articles Section */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display font-bold text-xl text-bhub-navy-dark dark:text-white">
                Artigos Recentes
              </h2>
              <a
                href="/articles"
                className="text-bhub-teal-primary hover:text-bhub-teal-primary/80 font-body font-medium text-sm flex items-center gap-1"
              >
                Ver todos
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </a>
            </div>
            
            <ArticleCardList 
              articles={articles} 
              columns={1}
            />
          </section>
          
          {/* Newsletter Card */}
          <NewsletterCard />
          
          {/* Filter Sidebar (Mobile) */}
          <FilterSidebar />
        </div>
      </main>
      
      <Footer />
    </MainLayout>
  );
}