'use client';

import React, { useState } from 'react';
import { Header } from '@/components/Layout/Header';
import { Footer } from '@/components/Layout/Footer';
import { MainLayout } from '@/components/Layout/MainLayout';
import { Badge } from '@/components/Badge/Badge';
import { AuthorAvatar } from '@/components/Avatar/Avatar';
import { Button } from '@/components/Button/Button';
import { Icon } from '@/components/Icon/Icon';

export function ArticleDetailPage() {
  const [isLiked, setIsLiked] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [activeTab, setActiveTab] = useState('abstract');

  // Mock article data
  const article = {
    id: '1',
    title: 'Avanços na Terapia Comportamental para Transtornos do Espectro Autista: Uma Revisão Sistemática',
    excerpt: 'Esta revisão sistemática examina os desenvolvimentos recentes na terapia comportamental aplicada ao tratamento de transtornos do espectro autista.',
    abstract: `Esta revisão sistemática examina os desenvolvimentos recentes na terapia comportamental aplicada ao tratamento de transtornos do espectro autista. Foram analisados 42 estudos publicados entre 2019 e 2024, avaliando a eficácia de diferentes abordagens terapêuticas baseadas em princípios behavioristas. Os resultados indicam melhorias significativas em áreas cruciais do desenvolvimento, incluindo comunicação, habilidades sociais e comportamentos adaptativos. Análises de metadados revelam que intervenções precoces e intensivas apresentam os melhores resultados clínicos, com efeitos mantidos a longo prazo em 78% dos casos estudados.`,
    content: `# Introdução

Os transtornos do espectro autista (TEA) representam um conjunto de condições neurodesenvolvimentais caracterizadas por déficits persistentes na comunicação social interativa e padrões restritos e repetitivos de comportamento, interesses ou atividades. A prevalência mundial tem aumentado significativamente nas últimas décadas, com estimativas atuais sugerindo aproximadamente 1 em cada 36 crianças diagnosticadas com TEA.

A terapia comportamental baseada em princípios da análise do comportamento aplicada (ABA) tem sido uma das abordagens mais estudadas e utilizadas no tratamento de TEA. Este trabalho apresenta uma revisão sistemática da literatura recente sobre avanços nesta área.

# Métodos

Foi realizada uma busca sistemática nas bases de dados PubMed, PsycINFO e Scopus, incluindo estudos publicados entre janeiro de 2019 e dezembro de 2024. Os critérios de inclusão foram: (1) estudos empíricos publicados em inglês ou português; (2) foco em intervenções comportamentais para TEA; (3) participantes com diagnóstico formal de TEA; (4) mensuração de outcomes comportamentais objetivos.

# Resultados

Foram identificados 42 estudos que atenderam aos critérios de inclusão. As intervenções foram categorizadas em: (a) treinamento de habilidades sociais, (b) comunicação funcional, (c) manejo de comportamentos desafiadores, e (d) desenvolvimento acadêmico e cognitivo.

## Eficácia por Categoria

**Treinamento de Habilidades Sociais**: 89% dos estudos reportaram melhorias significativas em interações sociais, com tamanho de efeito médio de d = 0.78.

**Comunicação Funcional**: Intervenções focadas em comunicação alternativa e aumentativa mostraram resultados particularmente promissores, com 92% de sucesso em estabelecer sistemas funcionais de comunicação.

**Manejo Comportamental**: Estratégias baseadas em análise funcional e reforçamento diferencial reduziram comportamentos desafiadores em média 67% dos casos.

# Discussão

Os resultados desta revisão sistemática demonstram o contínuo avanço das terapias comportamentais para TEA. A evolução de abordagens mais individualizadas e baseadas em evidências tem contribuído para outcomes mais consistentes e generalizáveis.

## Implicações Clínicas

Os achados sugerem que intervenções precoces (< 3 anos) e intensivas (> 20 horas semanais) apresentam os melhores prognósticos. Além disso, a inclusão de cuidadores no processo terapêutico demonstrou ser um fator crítico para manutenção de ganhos a longo prazo.

## Limitações

Apesar dos resultados promissores, algumas limitações devem ser consideradas. A heterogeneidade dos estudos dificulta comparações diretas, e muitos apresentam amostras pequenas e falta de seguimento a longo prazo.

# Conclusão

Esta revisão sistemática demonstra que as terapias comportamentais continuam evoluindo e oferecendo resultados cada vez mais eficazes no tratamento de TEA. Futuras pesquisas devem focar em identificar os mecanismos subjacentes à mudança comportamental e desenvolver protocolos mais eficientes e escaláveis.`,
    category: {
      label: 'Terapia Comportamental',
      icon: null
    },
    date: '15 Dez 2025',
    citations: 47,
    downloads: 892,
    readingTime: 14,
    author: {
      name: 'Ana Silva',
      initials: 'AS',
      affiliation: 'Universidade de São Paulo - Departamento de Psicologia',
      email: 'ana.silva@usp.br'
    },
    coauthors: [
      { name: 'Carlos Santos', initials: 'CS', affiliation: 'Universidade Federal do Rio de Janeiro' },
      { name: 'Maria Oliveira', initials: 'MO', affiliation: 'Universidade de Brasília' }
    ],
    keywords: ['Autismo', 'Terapia Comportamental', 'Análise do Comportamento', 'TEA', 'Intervenção Precoce'],
    doi: '10.1234/bhub.2025.001',
    journal: 'Journal of Behavior Analysis',
    volume: '42',
    issue: '3',
    pages: '245-267'
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
  };

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.excerpt,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  const handleDownload = () => {
    console.log('Downloading article PDF');
    // In a real app, this would trigger a PDF download
  };

  const tabs = [
    { id: 'abstract', label: 'Resumo' },
    { id: 'content', label: 'Conteúdo Completo' },
    { id: 'references', label: 'Referências' },
    { id: 'metrics', label: 'Métricas' }
  ];

  return (
    <MainLayout>
      <Header />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Article Header */}
        <header className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <Badge 
              label={article.category.label}
              icon={article.category.icon}
              variant="default"
            />
            <span className="text-sm text-gray-500 dark:text-gray-400">
              {article.date}
            </span>
          </div>
          
          <h1 className="font-display font-bold text-3xl md:text-4xl text-bhub-navy-dark dark:text-white mb-4 leading-tight">
            {article.title}
          </h1>
          
          <p className="font-body font-light text-lg text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
            {article.excerpt}
          </p>

          {/* Authors Section */}
          <div className="flex items-center gap-4 mb-6">
            <AuthorAvatar 
              name={article.author.name}
              initials={article.author.initials}
              size="lg"
            />
            <div>
              <p className="font-body font-medium text-gray-900 dark:text-white">
                {article.author.name}
              </p>
              <p className="font-body font-light text-sm text-gray-600 dark:text-gray-400">
                {article.author.affiliation}
              </p>
            </div>
          </div>

          {/* Article Metadata */}
          <div className="flex flex-wrap items-center gap-6 text-sm text-gray-500 dark:text-gray-400">
            <span className="flex items-center gap-1">
              <Icon name="star" size="sm" />
              {article.citations} citações
            </span>
            <span className="flex items-center gap-1">
              <Icon name="download" size="sm" />
              {article.downloads} downloads
            </span>
            <span className="flex items-center gap-1">
              <Icon name="clock" size="sm" />
              {article.readingTime} min leitura
            </span>
            <span className="flex items-center gap-1">
              <Icon name="eye" size="sm" />
              DOI: {article.doi}
            </span>
          </div>
        </header>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          <Button
            variant="default"
            onClick={handleDownload}
            className="bg-bhub-teal-primary hover:bg-bhub-teal-primary/90"
          >
            <Icon name="download" size="sm" />
            Baixar PDF
          </Button>
          
          <Button
            variant="outline"
            onClick={handleLike}
            className={isLiked ? 'text-bhub-red-accent border-bhub-red-accent' : ''}
          >
            <Icon name="heart" size="sm" />
            {isLiked ? 'Curtido' : 'Curtir'}
          </Button>
          
          <Button
            variant="outline"
            onClick={handleBookmark}
            className={isBookmarked ? 'text-bhub-yellow-primary border-bhub-yellow-primary' : ''}
          >
            <Icon name="bookmark" size="sm" />
            {isBookmarked ? 'Salvo' : 'Salvar'}
          </Button>
          
          <Button
            variant="outline"
            onClick={handleShare}
          >
            <Icon name="share" size="sm" />
            Compartilhar
          </Button>
        </div>

        {/* Content Tabs */}
        <div className="border-b border-gray-200 dark:border-gray-700 mb-8">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-bhub-teal-primary text-bhub-teal-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <div className="prose prose-lg dark:prose-invert max-w-none">
          {activeTab === 'abstract' && (
            <div className="font-body font-light text-gray-700 dark:text-gray-300 leading-relaxed">
              {article.abstract}
            </div>
          )}
          
          {activeTab === 'content' && (
            <div className="font-body font-light text-gray-700 dark:text-gray-300 leading-relaxed">
              <div dangerouslySetInnerHTML={{ __html: article.content.replace(/\n/g, '<br>') }} />
            </div>
          )}
          
          {activeTab === 'references' && (
            <div className="space-y-4">
              <h3 className="font-display font-bold text-xl text-bhub-navy-dark dark:text-white mb-4">
                Referências Bibliográficas
              </h3>
              <div className="space-y-3">
                {[
                  'Smith, J. et al. (2024). Behavioral interventions for autism: A meta-analysis. Journal of Applied Behavior Analysis, 57(2), 123-145.',
                  'Johnson, M. & Brown, K. (2023). Early intervention outcomes in ASD. Clinical Psychology Review, 45, 78-92.',
                  'Davis, R. et al. (2023). Functional communication training: Long-term outcomes. Behavior Therapy, 54(1), 45-62.'
                ].map((reference, index) => (
                  <p key={index} className="font-body font-light text-sm text-gray-700 dark:text-gray-300">
                    {index + 1}. {reference}
                  </p>
                ))}
              </div>
            </div>
          )}
          
          {activeTab === 'metrics' && (
            <div className="space-y-6">
              <h3 className="font-display font-bold text-xl text-bhub-navy-dark dark:text-white mb-4">
                Métricas e Impacto
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                  <h4 className="font-body font-semibold text-gray-900 dark:text-white mb-2">
                    Engajamento
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Visualizações</span>
                      <span className="font-medium">2,847</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Downloads</span>
                      <span className="font-medium">{article.downloads}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Compartilhamentos</span>
                      <span className="font-medium">156</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                  <h4 className="font-body font-semibold text-gray-900 dark:text-white mb-2">
                    Impacto Acadêmico
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Citações</span>
                      <span className="font-medium">{article.citations}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">Fator de Impacto</span>
                      <span className="font-medium">3.2</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600 dark:text-gray-400">H-index do autor</span>
                      <span className="font-medium">12</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Keywords */}
        <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-700">
          <h3 className="font-body font-semibold text-sm text-gray-900 dark:text-white mb-3">
            Palavras-chave
          </h3>
          <div className="flex flex-wrap gap-2">
            {article.keywords.map((keyword) => (
              <Badge
                key={keyword}
                label={keyword}
                variant="light"
                className="text-xs"
              />
            ))}
          </div>
        </div>
      </main>
      
      <Footer />
    </MainLayout>
  );
}