export interface Category {
  id: string;
  label: string;
  icon?: string;
  count?: number;
}

export class CategoryService {
  static async getAll(): Promise<Category[]> {
    const response = await fetch('/api/categories');
    if (!response.ok) {
      throw new Error('Failed to fetch categories');
    }
    return response.json();
  }

  static async getById(id: string): Promise<Category> {
    const response = await fetch(`/api/categories/${id}`);
    if (!response.ok) {
      throw new Error('Failed to fetch category');
    }
    return response.json();
  }

  static async getArticlesByCategory(categoryId: string): Promise<any[]> {
    const response = await fetch(`/api/categories/${categoryId}/articles`);
    if (!response.ok) {
      throw new Error('Failed to fetch articles by category');
    }
    return response.json();
  }
}