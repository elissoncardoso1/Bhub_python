import { Article, ListParams } from '@/types/article';

export class ArticleService {
  static async getFeatured(): Promise<Article> {
    const response = await fetch('/api/articles/featured');
    if (!response.ok) {
      throw new Error('Failed to fetch featured article');
    }
    return response.json();
  }

  static async list(params?: ListParams): Promise<Article[]> {
    const query = new URLSearchParams();
    
    if (params?.category) query.append('category', params.category);
    if (params?.author) query.append('author', params.author);
    if (params?.search) query.append('search', params.search);
    if (params?.page) query.append('page', params.page.toString());
    if (params?.limit) query.append('limit', params.limit.toString());
    if (params?.sort) query.append('sort', params.sort);
    if (params?.order) query.append('order', params.order);

    const url = `/api/articles${query.toString() ? `?${query.toString()}` : ''}`;
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error('Failed to fetch articles');
    }
    
    return response.json();
  }

  static async getById(id: string): Promise<Article> {
    const response = await fetch(`/api/articles/${id}`);
    if (!response.ok) {
      throw new Error('Failed to fetch article');
    }
    return response.json();
  }

  static async toggleFavorite(id: string): Promise<void> {
    await fetch(`/api/favorites/${id}`, { method: 'POST' });
  }

  static async getFavorites(): Promise<Article[]> {
    const response = await fetch('/api/favorites');
    if (!response.ok) {
      throw new Error('Failed to fetch favorites');
    }
    return response.json();
  }

  static async addToFavorites(id: string): Promise<void> {
    await fetch(`/api/favorites/${id}`, { method: 'POST' });
  }

  static async removeFromFavorites(id: string): Promise<void> {
    await fetch(`/api/favorites/${id}`, { method: 'DELETE' });
  }

  static async getTrending(): Promise<Article[]> {
    const response = await fetch('/api/articles/trending');
    if (!response.ok) {
      throw new Error('Failed to fetch trending articles');
    }
    return response.json();
  }

  static async search(query: string, filters?: Partial<ListParams>): Promise<Article[]> {
    const params = new URLSearchParams({
      search: query,
      ...filters
    });

    const response = await fetch(`/api/articles/search?${params.toString()}`);
    if (!response.ok) {
      throw new Error('Failed to search articles');
    }
    return response.json();
  }
}