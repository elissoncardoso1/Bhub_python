import { Author } from '@/types/article';

export class AuthorService {
  static async getAll(): Promise<Author[]> {
    const response = await fetch('/api/authors');
    if (!response.ok) {
      throw new Error('Failed to fetch authors');
    }
    return response.json();
  }

  static async getById(id: string): Promise<Author> {
    const response = await fetch(`/api/authors/${id}`);
    if (!response.ok) {
      throw new Error('Failed to fetch author');
    }
    return response.json();
  }

  static async getArticlesByAuthor(authorId: string): Promise<any[]> {
    const response = await fetch(`/api/authors/${authorId}/articles`);
    if (!response.ok) {
      throw new Error('Failed to fetch articles by author');
    }
    return response.json();
  }

  static async getTopAuthors(limit: number = 10): Promise<Author[]> {
    const response = await fetch(`/api/authors/top?limit=${limit}`);
    if (!response.ok) {
      throw new Error('Failed to fetch top authors');
    }
    return response.json();
  }
}